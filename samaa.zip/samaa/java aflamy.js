function changeBackground(){
	var text =document.getElementById("pare").style.backgroundColor="gray";

}
function backToNormal(){
	var text=document.getElementById("pare").style.backgroundColor="";
}
function changeBackground(){
	var text =document.getElementById("para").style.backgroundColor="lightgray";
	

}
function backToNormal(){
	var text=document.getElementById("para").style.backgroundColor="";
}